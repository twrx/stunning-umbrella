class Micropost < ApplicationRecord
end
