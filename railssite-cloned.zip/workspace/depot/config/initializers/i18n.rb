#encoding: utf-8
I18n.default_locale = :en
LANGUAGES = [
['English', 'en'],
["Espa&ntilde;ol".html_safe, 'es']
]
